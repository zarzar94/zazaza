"use client"

import { useState, useEffect } from "react"
import type { WizardData } from "../wizard-modal"

interface SubmissionStepProps {
  serviceType: "complaint" | "suggestion"
  data: WizardData
  onClose: () => void
}

export function SubmissionStep({ serviceType, data, onClose }: SubmissionStepProps) {
  const [isSubmitting, setIsSubmitting] = useState(true)
  const [isSuccess, setIsSuccess] = useState(false)
  const [trackingNumber, setTrackingNumber] = useState("")

  useEffect(() => {
    // Simulate submission process
    const timer = setTimeout(() => {
      setIsSubmitting(false)
      setIsSuccess(true)
      // Generate a random tracking number
      const randomNum = Math.floor(Math.random() * 1000000)
        .toString()
        .padStart(6, "0")
      setTrackingNumber(`DL-${serviceType === "complaint" ? "C" : "S"}-${randomNum}`)
    }, 3000)

    return () => clearTimeout(timer)
  }, [serviceType])

  if (isSubmitting) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin w-16 h-16 border-4 border-[#1a5450] border-t-transparent rounded-full mx-auto mb-6"></div>
        <h2 className="text-2xl font-bold mb-4">جاري إرسال الطلب...</h2>
        <p className="text-gray-600">يرجى الانتظار، سيتم إرسال طلبك خلال لحظات</p>
      </div>
    )
  }

  if (isSuccess) {
    return (
      <div className="text-center py-8">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <span className="text-4xl text-green-600">✓</span>
        </div>

        <h2 className="text-2xl font-bold text-green-600 mb-4">
          تم إرسال {serviceType === "complaint" ? "الشكوى" : "الاقتراح"} بنجاح!
        </h2>

        <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
          <div className="text-lg font-semibold text-green-800 mb-2">رقم المتابعة</div>
          <div className="text-2xl font-bold text-green-600 font-mono">{trackingNumber}</div>
          <div className="text-sm text-green-700 mt-2">احتفظ بهذا الرقم لمتابعة حالة طلبك</div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 text-right">
          <h3 className="font-semibold text-blue-800 mb-3">الخطوات التالية:</h3>
          <div className="space-y-2 text-sm text-blue-700">
            <div>• سيتم مراجعة طلبك من قبل الفريق المختص خلال 24 ساعة</div>
            <div>• ستحصل على تأكيد استلام عبر الهاتف أو البريد الإلكتروني</div>
            <div>• مدة المعالجة المتوقعة: 5-10 أيام عمل</div>
            <div>• يمكنك متابعة حالة الطلب باستخدام رقم المتابعة</div>
          </div>
        </div>

        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-6">
          <h3 className="font-semibold text-gray-800 mb-3">معلومات الاتصال:</h3>
          <div className="space-y-1 text-sm text-gray-600">
            <div>📞 الخط الساخن: 133</div>
            <div>📧 البريد الإلكتروني: info@mof.gov.sy</div>
            <div>🌐 الموقع الإلكتروني: www.mof.gov.sy</div>
          </div>
        </div>

        <div className="flex gap-4 justify-center">
          <button
            onClick={() => window.print()}
            className="px-6 py-3 border border-[#1a5450] text-[#1a5450] rounded-lg hover:bg-[#1a5450] hover:text-white transition-colors"
          >
            طباعة الإيصال
          </button>
          <button
            onClick={onClose}
            className="px-6 py-3 bg-[#1a5450] text-white rounded-lg hover:bg-[#0f3835] transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    )
  }

  return null
}
