"use client"

import { useState } from "react"
import type { WizardData } from "../wizard-modal"

interface CategoryStepProps {
  serviceType: "complaint" | "suggestion"
  data: WizardData
  updateData: (data: Partial<WizardData>) => void
  onNext: () => void
}

export function CategoryStep({ serviceType, data, updateData, onNext }: CategoryStepProps) {
  const [selectedCategory, setSelectedCategory] = useState(data.category)

  const complaintCategories = [
    { id: "tax-dispute", label: "نزاع ضريبي", description: "خلافات حول التقديرات الضريبية أو الغرامات" },
    { id: "service-quality", label: "جودة الخدمة", description: "شكاوى حول مستوى الخدمة المقدمة" },
    { id: "employee-conduct", label: "سلوك الموظفين", description: "شكاوى حول تعامل الموظفين" },
    { id: "corruption", label: "فساد أو رشوة", description: "بلاغات عن حالات فساد أو طلب رشاوى" },
    { id: "system-technical", label: "مشاكل تقنية", description: "مشاكل في الأنظمة الإلكترونية" },
    { id: "other", label: "أخرى", description: "شكاوى أخرى لا تندرج تحت الفئات السابقة" },
  ]

  const suggestionCategories = [
    { id: "service-improvement", label: "تحسين الخدمات", description: "اقتراحات لتطوير الخدمات الحالية" },
    { id: "new-service", label: "خدمة جديدة", description: "اقتراح خدمات جديدة" },
    { id: "system-enhancement", label: "تطوير الأنظمة", description: "اقتراحات لتحسين الأنظمة التقنية" },
    { id: "policy-suggestion", label: "اقتراح سياسة", description: "اقتراحات حول السياسات والإجراءات" },
    { id: "other", label: "أخرى", description: "اقتراحات أخرى" },
  ]

  const categories = serviceType === "complaint" ? complaintCategories : suggestionCategories

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId)
    updateData({ category: categoryId })
  }

  const handleNext = () => {
    if (selectedCategory) {
      onNext()
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">
          {serviceType === "complaint" ? "اختيار فئة الشكوى" : "اختيار فئة الاقتراح"}
        </h2>
        <p className="text-gray-600">يرجى اختيار الفئة المناسبة لضمان معالجة طلبكم من الجهة المختصة</p>
      </div>

      <div className="space-y-3">
        <label className="block text-sm font-semibold text-gray-700 mb-3">
          فئة الطلب: <span className="text-red-500">*</span>
        </label>
        {categories.map((category) => (
          <div
            key={category.id}
            className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
              selectedCategory === category.id
                ? "border-[#1a5450] bg-[#1a5450] bg-opacity-5"
                : "border-gray-200 hover:border-gray-300"
            }`}
            onClick={() => handleCategorySelect(category.id)}
          >
            <div className="flex items-start gap-3">
              <input
                type="radio"
                name="category"
                value={category.id}
                checked={selectedCategory === category.id}
                onChange={() => handleCategorySelect(category.id)}
                className="mt-1"
              />
              <div>
                <div className="font-semibold text-gray-800">{category.label}</div>
                <div className="text-sm text-gray-600 mt-1">{category.description}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Alternative Channels for Complaints */}
      {serviceType === "complaint" && selectedCategory && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xl">💡</span>
            <span className="font-semibold text-blue-800">قنوات بديلة لتقديم الشكاوى</span>
          </div>
          <div className="space-y-2 text-sm">
            <div>
              • البوابة الحكومية الإلكترونية:{" "}
              <a href="#" className="text-blue-600 underline">
                gov.sy
              </a>
            </div>
            <div>
              • واتساب الجمارك:{" "}
              <a href="#" className="text-blue-600 underline">
                +963-xxx-xxx-xxx
              </a>
            </div>
            {selectedCategory === "corruption" && (
              <div>
                • هيئة مكافحة الفساد:{" "}
                <a href="#" className="text-blue-600 underline">
                  anticorruption.gov.sy
                </a>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Guidance Section */}
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <div className="font-semibold text-gray-800 mb-2">كيف يُعالج طلبك؟</div>
        <div className="text-sm text-gray-600 space-y-1">
          <div>• سيتم توجيه طلبك إلى القسم المختص</div>
          <div>• ستحصل على رقم متابعة خلال 24 ساعة</div>
          <div>• مدة المعالجة: 5-10 أيام عمل</div>
          <div>• سيتم إشعارك بالنتيجة عبر الهاتف أو البريد الإلكتروني</div>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={handleNext}
          disabled={!selectedCategory}
          className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
            selectedCategory
              ? "bg-[#1a5450] text-white hover:bg-[#0f3835]"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          }`}
        >
          التالي ←
        </button>
      </div>
    </div>
  )
}
