"use client"

import { useState } from "react"
import type { WizardData } from "../wizard-modal"

interface DetailsStepProps {
  serviceType: "complaint" | "suggestion"
  data: WizardData
  updateData: (data: Partial<WizardData>) => void
  onNext: () => void
  onPrev: () => void
}

export function DetailsStep({ serviceType, data, updateData, onNext, onPrev }: DetailsStepProps) {
  const [errors, setErrors] = useState<Record<string, string>>({})

  const governorates = [
    { id: "damascus", name: "دمشق" },
    { id: "aleppo", name: "حلب" },
    { id: "homs", name: "حمص" },
    { id: "hama", name: "حماة" },
    { id: "latakia", name: "اللاذقية" },
    { id: "tartous", name: "طرطوس" },
    { id: "idlib", name: "إدلب" },
    { id: "daraa", name: "درعا" },
    { id: "sweida", name: "السويداء" },
    { id: "quneitra", name: "القنيطرة" },
    { id: "deir", name: "دير الزور" },
    { id: "raqqa", name: "الرقة" },
    { id: "hasaka", name: "الحسكة" },
    { id: "damascus-countryside", name: "ريف دمشق" },
  ]

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!data.titleAr.trim()) {
      newErrors.titleAr = `يرجى إدخال عنوان ${serviceType === "complaint" ? "الشكوى" : "الاقتراح"}`
    }

    if (!data.description.trim()) {
      newErrors.description = `يرجى إدخال وصف تفصيلي`
    }

    if (!data.dataProcessing) {
      newErrors.dataProcessing = "يجب الموافقة على معالجة البيانات الشخصية"
    }

    if (!data.anonymous) {
      if (!data.fullName.trim()) {
        newErrors.fullName = "يرجى إدخال الاسم الكامل"
      }
      if (!data.phone.trim()) {
        newErrors.phone = "يرجى إدخال رقم الهاتف"
      }
      if (data.email && !/\S+@\S+\.\S+/.test(data.email)) {
        newErrors.email = "يرجى إدخال بريد إلكتروني صحيح"
      }
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleNext = () => {
    if (validateForm()) {
      onNext()
    }
  }

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          updateData({
            location: {
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            },
          })
          alert("تم تحديد الموقع بنجاح")
        },
        (error) => {
          alert("لم يتم تحديد الموقع. يرجى المحاولة مرة أخرى أو إدخال العنوان يدوياً")
        },
      )
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">تفاصيل الطلب</h2>
        <p className="text-gray-600">يرجى شرح طلبك بشكل واضح وموجز مع ذكر أي تفاصيل داعمة</p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            عنوان {serviceType === "complaint" ? "الشكوى" : "الاقتراح"} <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={data.titleAr}
            onChange={(e) => updateData({ titleAr: e.target.value })}
            className={`w-full p-3 border rounded-lg ${errors.titleAr ? "border-red-500" : "border-gray-300"}`}
            placeholder={`اكتب عنواناً واضحاً ${serviceType === "complaint" ? "للشكوى" : "للاقتراح"}`}
          />
          {errors.titleAr && <p className="text-red-500 text-sm mt-1">{errors.titleAr}</p>}
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Title in English (اختياري)</label>
          <input
            type="text"
            value={data.titleEn}
            onChange={(e) => updateData({ titleEn: e.target.value })}
            className="w-full p-3 border border-gray-300 rounded-lg"
            placeholder={`Enter ${serviceType} title in English`}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            وصف {serviceType === "complaint" ? "الشكوى" : "الاقتراح"} <span className="text-red-500">*</span>
          </label>
          <textarea
            value={data.description}
            onChange={(e) => updateData({ description: e.target.value })}
            rows={4}
            className={`w-full p-3 border rounded-lg ${errors.description ? "border-red-500" : "border-gray-300"}`}
            placeholder={`اشرح تفاصيل ${serviceType === "complaint" ? "الشكوى" : "الاقتراح"} بوضوح...`}
          />
          {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
        </div>

        {/* Location Section */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <label className="block text-sm font-semibold text-gray-700 mb-3">📍 معلومات الموقع</label>

          <div className="mb-4">
            <button
              type="button"
              onClick={getCurrentLocation}
              className="bg-blue-50 border border-[#1a5450] text-[#1a5450] px-4 py-2 rounded-lg hover:bg-blue-100 transition-colors"
            >
              📍 تحديد على الخريطة باستخدام GPS
            </button>
            {data.location && <p className="text-green-600 text-sm mt-2">✓ تم تحديد الموقع بنجاح</p>}
          </div>

          <div className="text-center text-gray-500 my-4">أو</div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                المحافظة <span className="text-red-500">*</span>
              </label>
              <select
                value={data.governorate}
                onChange={(e) => updateData({ governorate: e.target.value, city: "" })}
                className="w-full p-3 border border-gray-300 rounded-lg"
              >
                <option value="">اختر المحافظة</option>
                {governorates.map((gov) => (
                  <option key={gov.id} value={gov.id}>
                    {gov.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">المدينة/المنطقة</label>
              <input
                type="text"
                value={data.city}
                onChange={(e) => updateData({ city: e.target.value })}
                className="w-full p-3 border border-gray-300 rounded-lg"
                placeholder="المدينة أو المنطقة"
              />
            </div>
          </div>

          <div className="mt-4">
            <input
              type="text"
              value={data.address}
              onChange={(e) => updateData({ address: e.target.value })}
              className="w-full p-3 border border-gray-300 rounded-lg"
              placeholder="الشارع، الحي، معالم بارزة..."
            />
          </div>
        </div>

        {/* Privacy Options */}
        <div className="bg-yellow-50 border-r-4 border-yellow-400 p-4 rounded">
          <div className="space-y-3">
            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={data.anonymous}
                onChange={(e) => updateData({ anonymous: e.target.checked })}
                className="mt-1"
              />
              <span className="text-sm">
                أرغب في تقديم {serviceType === "complaint" ? "الشكوى" : "الاقتراح"} بدون ذكر اسمي (مجهول)
              </span>
            </label>

            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={data.publicInfo}
                onChange={(e) => updateData({ publicInfo: e.target.checked })}
                className="mt-1"
              />
              <span className="text-sm">
                أوافق على عرض {serviceType === "complaint" ? "الشكوى" : "الاقتراح"} في التقارير العامة (بدون معلومات
                شخصية)
              </span>
            </label>

            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={data.dataProcessing}
                onChange={(e) => updateData({ dataProcessing: e.target.checked })}
                className="mt-1"
              />
              <span className="text-sm">
                أوافق على معالجة بياناتي الشخصية لأغراض معالجة {serviceType === "complaint" ? "الشكوى" : "الاقتراح"}{" "}
                <span className="text-red-500">*</span>
              </span>
            </label>
            {errors.dataProcessing && <p className="text-red-500 text-sm">{errors.dataProcessing}</p>}

            <label className="flex items-start gap-3">
              <input
                type="checkbox"
                checked={data.followUp}
                onChange={(e) => updateData({ followUp: e.target.checked })}
                className="mt-1"
              />
              <span className="text-sm">
                أوافق على التواصل معي لمتابعة {serviceType === "complaint" ? "الشكوى" : "الاقتراح"}
              </span>
            </label>
          </div>
        </div>

        {/* Personal Information */}
        {!data.anonymous && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">المعلومات الشخصية</h3>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                الاسم الكامل <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={data.fullName}
                onChange={(e) => updateData({ fullName: e.target.value })}
                className={`w-full p-3 border rounded-lg ${errors.fullName ? "border-red-500" : "border-gray-300"}`}
              />
              {errors.fullName && <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>}
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                رقم الهاتف <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                value={data.phone}
                onChange={(e) => updateData({ phone: e.target.value })}
                className={`w-full p-3 border rounded-lg ${errors.phone ? "border-red-500" : "border-gray-300"}`}
                placeholder="+963xxxxxxxxx"
              />
              {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">البريد الإلكتروني</label>
              <input
                type="email"
                value={data.email}
                onChange={(e) => updateData({ email: e.target.value })}
                className={`w-full p-3 border rounded-lg ${errors.email ? "border-red-500" : "border-gray-300"}`}
                placeholder="example@email.com"
              />
              {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">الرقم الوطني</label>
              <input
                type="text"
                value={data.nationalId}
                onChange={(e) => updateData({ nationalId: e.target.value })}
                className="w-full p-3 border border-gray-300 rounded-lg"
                placeholder="xxxxxxxxxxx"
              />
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-between">
        <button
          onClick={onPrev}
          className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
        >
          → السابق
        </button>
        <button
          onClick={handleNext}
          className="px-6 py-3 bg-[#1a5450] text-white rounded-lg hover:bg-[#0f3835] transition-colors"
        >
          التالي ←
        </button>
      </div>
    </div>
  )
}
