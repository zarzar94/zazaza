"use client"

import type { WizardData } from "../wizard-modal"

interface ReviewStepProps {
  serviceType: "complaint" | "suggestion"
  data: WizardData
  onNext: () => void
  onPrev: () => void
}

export function ReviewStep({ serviceType, data, onNext, onPrev }: ReviewStepProps) {
  const getCategoryLabel = (category: string) => {
    const categories = {
      "tax-dispute": "نزاع ضريبي",
      "service-quality": "جودة الخدمة",
      "employee-conduct": "سلوك الموظفين",
      corruption: "فساد أو رشوة",
      "system-technical": "مشاكل تقنية",
      "service-improvement": "تحسين الخدمات",
      "new-service": "خدمة جديدة",
      "system-enhancement": "تطوير الأنظمة",
      "policy-suggestion": "اقتراح سياسة",
      other: "أخرى",
    }
    return categories[category as keyof typeof categories] || category
  }

  const getGovernorateLabel = (governorate: string) => {
    const governorates = {
      damascus: "دمشق",
      aleppo: "حلب",
      homs: "حمص",
      hama: "حماة",
      latakia: "اللاذقية",
      tartous: "طرطوس",
      idlib: "إدلب",
      daraa: "درعا",
      sweida: "السويداء",
      quneitra: "القنيطرة",
      deir: "دير الزور",
      raqqa: "الرقة",
      hasaka: "الحسكة",
      "damascus-countryside": "ريف دمشق",
    }
    return governorates[governorate as keyof typeof governorates] || governorate
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">مراجعة الطلب</h2>
        <p className="text-gray-600">يرجى التأكد من صحة المعلومات أدناه قبل الإرسال</p>
      </div>

      <div className="space-y-6">
        {/* Request Information */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="text-lg font-semibold mb-4 text-[#1a5450]">معلومات الطلب</h3>
          <div className="space-y-3">
            <div className="flex">
              <span className="font-medium text-gray-700 min-w-[120px]">نوع الطلب:</span>
              <span>{serviceType === "complaint" ? "شكوى" : "اقتراح"}</span>
            </div>
            <div className="flex">
              <span className="font-medium text-gray-700 min-w-[120px]">الفئة:</span>
              <span>{getCategoryLabel(data.category)}</span>
            </div>
            <div className="flex">
              <span className="font-medium text-gray-700 min-w-[120px]">العنوان:</span>
              <span>{data.titleAr}</span>
            </div>
            {data.titleEn && (
              <div className="flex">
                <span className="font-medium text-gray-700 min-w-[120px]">العنوان (EN):</span>
                <span>{data.titleEn}</span>
              </div>
            )}
            <div className="flex flex-col">
              <span className="font-medium text-gray-700 mb-2">الوصف:</span>
              <span className="bg-white p-3 rounded border text-sm">{data.description}</span>
            </div>
          </div>
        </div>

        {/* Location Information */}
        {(data.governorate || data.city || data.address || data.location) && (
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold mb-4 text-[#1a5450]">معلومات الموقع</h3>
            <div className="space-y-3">
              {data.governorate && (
                <div className="flex">
                  <span className="font-medium text-gray-700 min-w-[120px]">المحافظة:</span>
                  <span>{getGovernorateLabel(data.governorate)}</span>
                </div>
              )}
              {data.city && (
                <div className="flex">
                  <span className="font-medium text-gray-700 min-w-[120px]">المدينة:</span>
                  <span>{data.city}</span>
                </div>
              )}
              {data.address && (
                <div className="flex">
                  <span className="font-medium text-gray-700 min-w-[120px]">العنوان:</span>
                  <span>{data.address}</span>
                </div>
              )}
              {data.location && (
                <div className="flex">
                  <span className="font-medium text-gray-700 min-w-[120px]">الإحداثيات:</span>
                  <span>📍 تم تحديد الموقع بواسطة GPS</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Personal Information */}
        {!data.anonymous && (
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold mb-4 text-[#1a5450]">المعلومات الشخصية</h3>
            <div className="space-y-3">
              <div className="flex">
                <span className="font-medium text-gray-700 min-w-[120px]">الاسم:</span>
                <span>{data.fullName}</span>
              </div>
              <div className="flex">
                <span className="font-medium text-gray-700 min-w-[120px]">الهاتف:</span>
                <span>{data.phone}</span>
              </div>
              {data.email && (
                <div className="flex">
                  <span className="font-medium text-gray-700 min-w-[120px]">البريد:</span>
                  <span>{data.email}</span>
                </div>
              )}
              {data.nationalId && (
                <div className="flex">
                  <span className="font-medium text-gray-700 min-w-[120px]">الرقم الوطني:</span>
                  <span>{data.nationalId}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Privacy Settings */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="text-lg font-semibold mb-4 text-[#1a5450]">إعدادات الخصوصية</h3>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className={data.anonymous ? "text-green-600" : "text-gray-500"}>{data.anonymous ? "✓" : "✗"}</span>
              <span>طلب مجهول</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={data.publicInfo ? "text-green-600" : "text-gray-500"}>
                {data.publicInfo ? "✓" : "✗"}
              </span>
              <span>السماح بالعرض في التقارير العامة</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={data.followUp ? "text-green-600" : "text-gray-500"}>{data.followUp ? "✓" : "✗"}</span>
              <span>السماح بالمتابعة</span>
            </div>
          </div>
        </div>

        {/* Attachments */}
        {data.attachments.length > 0 && (
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold mb-4 text-[#1a5450]">المرفقات ({data.attachments.length})</h3>
            <div className="space-y-2">
              {data.attachments.map((file, index) => (
                <div key={index} className="flex items-center gap-3">
                  <span className="text-xl">
                    {file.type.includes("pdf") ? "📄" : file.type.includes("image") ? "🖼️" : "📝"}
                  </span>
                  <span className="text-sm">{file.name}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
        <div className="flex items-start gap-3">
          <span className="text-yellow-600 text-xl">⚠️</span>
          <div>
            <div className="font-semibold text-yellow-800 mb-1">تأكيد الإرسال</div>
            <div className="text-sm text-yellow-700">
              بالضغط على "إرسال الطلب" فإنك تؤكد صحة المعلومات المدخلة وموافقتك على شروط الخدمة. سيتم إرسال رقم المتابعة
              إلى الهاتف أو البريد الإلكتروني المحدد.
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-between">
        <button
          onClick={onPrev}
          className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
        >
          → السابق
        </button>
        <button
          onClick={onNext}
          className="px-6 py-3 bg-[#1a5450] text-white rounded-lg hover:bg-[#0f3835] transition-colors"
        >
          إرسال الطلب ←
        </button>
      </div>
    </div>
  )
}
