"use client"

import type React from "react"

import { useState } from "react"
import type { WizardData } from "../wizard-modal"
import { X, Upload } from "lucide-react"

interface AttachmentsStepProps {
  data: WizardData
  updateData: (data: Partial<WizardData>) => void
  onNext: () => void
  onPrev: () => void
}

export function AttachmentsStep({ data, updateData, onNext, onPrev }: AttachmentsStepProps) {
  const [dragOver, setDragOver] = useState(false)

  const handleFiles = (files: FileList | null) => {
    if (!files) return

    const validFiles: File[] = []
    const maxSize = 5 * 1024 * 1024 // 5MB
    const allowedTypes = [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ]

    Array.from(files).forEach((file) => {
      if (file.size > maxSize) {
        alert(`الملف ${file.name} كبير جداً. الحد الأقصى 5MB`)
        return
      }
      if (!allowedTypes.includes(file.type)) {
        alert(`نوع الملف ${file.name} غير مدعوم`)
        return
      }
      validFiles.push(file)
    })

    updateData({ attachments: [...data.attachments, ...validFiles] })
  }

  const removeFile = (index: number) => {
    const newAttachments = data.attachments.filter((_, i) => i !== index)
    updateData({ attachments: newAttachments })
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    handleFiles(e.dataTransfer.files)
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">المرفقات (اختياري)</h2>
        <p className="text-gray-600">يمكنك إرفاق مستندات أو صور داعمة لطلبك</p>
      </div>

      {/* File Upload Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
          dragOver ? "border-[#1a5450] bg-[#1a5450] bg-opacity-5" : "border-gray-300 hover:border-gray-400"
        }`}
        onDrop={handleDrop}
        onDragOver={(e) => {
          e.preventDefault()
          setDragOver(true)
        }}
        onDragLeave={() => setDragOver(false)}
        onClick={() => document.getElementById("fileInput")?.click()}
      >
        <input
          type="file"
          id="fileInput"
          multiple
          accept=".pdf,.jpg,.jpeg,.png,.docx"
          onChange={(e) => handleFiles(e.target.files)}
          className="hidden"
        />
        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <div className="text-lg text-gray-700 mb-2">انقر لإرفاق ملف أو اسحب الملفات هنا</div>
        <div className="text-sm text-gray-500">الملفات المسموحة: PDF, JPEG, PNG, DOCX (حد أقصى 5MB لكل ملف)</div>
      </div>

      {/* File List */}
      {data.attachments.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">الملفات المرفقة ({data.attachments.length})</h3>
          {data.attachments.map((file, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="text-2xl">
                  {file.type.includes("pdf") ? "📄" : file.type.includes("image") ? "🖼️" : "📝"}
                </div>
                <div>
                  <div className="font-medium text-gray-800">{file.name}</div>
                  <div className="text-sm text-gray-500">{formatFileSize(file.size)}</div>
                </div>
              </div>
              <button
                onClick={() => removeFile(index)}
                className="w-8 h-8 bg-red-100 hover:bg-red-200 text-red-600 rounded-full flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="flex justify-between">
        <button
          onClick={onPrev}
          className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
        >
          → السابق
        </button>
        <button
          onClick={onNext}
          className="px-6 py-3 bg-[#1a5450] text-white rounded-lg hover:bg-[#0f3835] transition-colors"
        >
          التالي ←
        </button>
      </div>
    </div>
  )
}
