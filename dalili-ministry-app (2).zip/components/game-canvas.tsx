"use client"

import { useRef } from "react"
import { useRouter } from "next/navigation"

export function GameCanvas() {
  const canvasRef = useRef<HTMLDivElement>(null)
  const router = useRouter()

  const handleLogoClick = () => {
    router.push("/game")
  }

  const handleFollowUpClick = () => {
    router.push("/follow-up")
  }

  const handleLibraryClick = () => {
    router.push("/library")
  }

  const handleTaxCalculatorClick = () => {
    router.push("/tax-calculator")
  }

  const handleComplaintClick = () => {
    router.push("/submit/complaint/category")
  }

  const handleSuggestionClick = () => {
    router.push("/submit/suggestion/category")
  }

  return (
    <div ref={canvasRef} className="relative w-screen h-screen overflow-hidden">
      {/* Islamic Pattern Background */}
      <div
        className="absolute inset-0 pointer-events-none z-[1] opacity-[0.12]"
        style={{
          backgroundImage: "url('/images/pattern-white-converted.png')",
          backgroundRepeat: "repeat",
          backgroundSize: "600px auto",
          backgroundPosition: "left top",
        }}
      ></div>

      {/* Game Floor with Pattern */}
      <div
        className="absolute w-[200%] h-[200%] top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 rotate-x-[60deg] translate-z-[-100px] pointer-events-none z-0"
        style={{
          transformStyle: "preserve-3d",
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 200 200'%3E%3Cdefs%3E%3ClinearGradient id='patternGrad' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%234dd0e1;stop-opacity:0.1'/%3E%3Cstop offset='50%25' style='stop-color:%23ffd700;stop-opacity:0.05'/%3E%3Cstop offset='100%25' style='stop-color:%234dd0e1;stop-opacity:0.1'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cg fill='none' stroke='url(%23patternGrad)' strokeWidth='0.5'%3E%3Cpath d='M50,0 L50,50 L0,50 M50,50 L100,50 L100,0 M100,50 L100,100 L50,100 M100,100 L150,100 L150,50 M150,100 L150,150 L100,150 M150,150 L200,150 L200,100'/%3E%3Ccircle cx='50' cy='50' r='20'/%3E%3Ccircle cx='100' cy='50' r='20'/%3E%3Ccircle cx='150' cy='50' r='20'/%3E%3Ccircle cx='50' cy='100' r='20'/%3E%3Ccircle cx='100' cy='100' r='20'/%3E%3Ccircle cx='150' cy='100' r='20'/%3E%3Ccircle cx='50' cy='150' r='20'/%3E%3Ccircle cx='100' cy='150' r='20'/%3E%3Ccircle cx='150' cy='150' r='20'/%3E%3Cpath d='M25,25 L75,25 L75,75 L25,75 Z M75,25 L125,25 L125,75 L75,75 Z M125,25 L175,25 L175,75 L125,75 Z M25,75 L75,75 L75,125 L25,125 Z M75,75 L125,75 L125,125 L75,125 Z M125,75 L175,75 L175,125 L125,125 Z M25,125 L75,125 L75,175 L25,175 Z M75,125 L125,125 L125,175 L75,175 Z M125,125 L175,125 L175,175 L125,175 Z'/%3E%3C/g%3E%3C/svg%3E")`,
        }}
      ></div>

      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 border border-[#4dd0e1] border-opacity-20 rounded-full pointer-events-none animate-pulse"></div>

      <div className="absolute top-8 left-8 z-10 flex flex-col gap-2">
        <button
          onClick={handleTaxCalculatorClick}
          className="bg-transparent border-2 border-[#c9b037] text-[#c9b037] px-4 py-2 rounded-lg font-semibold hover:bg-[#c9b037] hover:text-[#1a5450] transition-colors duration-300 text-sm"
        >
          حاسبة الضرائب
        </button>

        <button
          onClick={handleComplaintClick}
          className="bg-transparent border-2 border-[#c9b037] text-[#c9b037] px-4 py-2 rounded-lg font-semibold hover:bg-[#c9b037] hover:text-[#1a5450] transition-colors duration-300 text-sm"
        >
          الشكاوى
        </button>

        <button
          onClick={handleSuggestionClick}
          className="bg-transparent border-2 border-[#c9b037] text-[#c9b037] px-4 py-2 rounded-lg font-semibold hover:bg-[#c9b037] hover:text-[#1a5450] transition-colors duration-300 text-sm"
        >
          الاقتراحات
        </button>

        <button
          onClick={handleFollowUpClick}
          className="bg-transparent border-2 border-[#c9b037] text-[#c9b037] px-4 py-2 rounded-lg font-semibold hover:bg-[#c9b037] hover:text-[#1a5450] transition-colors duration-300 text-sm"
        >
          متابعة
        </button>

        <button
          onClick={handleLibraryClick}
          className="bg-transparent border-2 border-[#c9b037] text-[#c9b037] px-4 py-2 rounded-lg font-semibold hover:bg-[#c9b037] hover:text-[#1a5450] transition-colors duration-300 text-sm"
        >
          المكتبة
        </button>
      </div>

      {/* Ministry Logo */}
      <div className="absolute top-8 right-8 z-10">
        <img src="/images/ministry-logo.png" alt="وزارة المالية" className="h-16 opacity-80" />
      </div>
    </div>
  )
}
