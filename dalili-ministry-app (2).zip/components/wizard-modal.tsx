"use client"

import { useState } from "react"
import { X } from "lucide-react"
import { CategoryStep } from "./wizard-steps/category-step"
import { DetailsStep } from "./wizard-steps/details-step"
import { AttachmentsStep } from "./wizard-steps/attachments-step"
import { ReviewStep } from "./wizard-steps/review-step"
import { SubmissionStep } from "./wizard-steps/submission-step"

interface WizardModalProps {
  serviceType: "complaint" | "suggestion"
  onClose: () => void
}

export interface WizardData {
  category: string
  titleAr: string
  titleEn: string
  description: string
  governorate: string
  city: string
  address: string
  location?: { lat: number; lng: number }
  anonymous: boolean
  publicInfo: boolean
  dataProcessing: boolean
  followUp: boolean
  fullName: string
  phone: string
  email: string
  nationalId: string
  attachments: File[]
}

export function WizardModal({ serviceType, onClose }: WizardModalProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [wizardData, setWizardData] = useState<WizardData>({
    category: "",
    titleAr: "",
    titleEn: "",
    description: "",
    governorate: "",
    city: "",
    address: "",
    anonymous: false,
    publicInfo: false,
    dataProcessing: false,
    followUp: false,
    fullName: "",
    phone: "",
    email: "",
    nationalId: "",
    attachments: [],
  })

  const totalSteps = 5
  const stepTitles = ["الفئة", "التفاصيل", "المرفقات", "المراجعة", "الإرسال"]

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const updateData = (data: Partial<WizardData>) => {
    setWizardData((prev) => ({ ...prev, ...data }))
  }

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <CategoryStep serviceType={serviceType} data={wizardData} updateData={updateData} onNext={nextStep} />
      case 2:
        return (
          <DetailsStep
            serviceType={serviceType}
            data={wizardData}
            updateData={updateData}
            onNext={nextStep}
            onPrev={prevStep}
          />
        )
      case 3:
        return <AttachmentsStep data={wizardData} updateData={updateData} onNext={nextStep} onPrev={prevStep} />
      case 4:
        return <ReviewStep serviceType={serviceType} data={wizardData} onNext={nextStep} onPrev={prevStep} />
      case 5:
        return <SubmissionStep serviceType={serviceType} data={wizardData} onClose={onClose} />
      default:
        return null
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto text-[#1a5450]"
        dir="rtl"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 w-8 h-8 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors z-10"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Ministry Header */}
        <div className="flex items-center gap-4 p-6 border-b border-gray-200">
          <div className="text-4xl">🏛️</div>
          <div>
            <div className="text-xl font-bold text-[#c9b037]">وزارة المالية</div>
            <div className="text-sm text-gray-600">نظام دليلي الضريبي</div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          {Array.from({ length: totalSteps }, (_, i) => (
            <div key={i} className="flex flex-col items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold ${
                  i + 1 <= currentStep ? "bg-[#1a5450] text-white" : "bg-gray-200 text-gray-500"
                }`}
              >
                {i + 1}
              </div>
              <div className={`text-xs mt-2 ${i + 1 <= currentStep ? "text-[#1a5450]" : "text-gray-500"}`}>
                {stepTitles[i]}
              </div>
            </div>
          ))}
        </div>

        {/* Step Content */}
        <div className="p-6">{renderStep()}</div>
      </div>
    </div>
  )
}
