"use client"

import { useRouter } from "next/navigation"
import { useEffect, useRef, useState } from "react"

export default function GamePage() {
  const router = useRouter()
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameState, setGameState] = useState({
    player: {
      x: 0,
      y: 0,
      speed: 4,
      direction: 0,
      lastX: 0,
      lastY: 0,
    },
    keys: {} as Record<string, boolean>,
    mouse: { x: 0, y: 0 },
    isRunning: true,
  })

  useEffect(() => {
    if (typeof window !== "undefined") {
      setGameState((prev) => ({
        ...prev,
        player: {
          ...prev.player,
          x: window.innerWidth / 2,
          y: window.innerHeight / 2,
          lastX: window.innerWidth / 2,
          lastY: window.innerHeight / 2,
        },
      }))
    }
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Game loop
    let animationId: number
    const gameLoop = () => {
      if (!gameState.isRunning) return

      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw background pattern
      ctx.fillStyle = "rgba(26, 84, 80, 1)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw grid pattern
      ctx.strokeStyle = "rgba(77, 208, 225, 0.1)"
      ctx.lineWidth = 1
      const gridSize = 50
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, canvas.height)
        ctx.stroke()
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(canvas.width, y)
        ctx.stroke()
      }

      // Draw player
      ctx.fillStyle = "#c9b037"
      ctx.beginPath()
      ctx.arc(gameState.player.x, gameState.player.y, 10, 0, Math.PI * 2)
      ctx.fill()

      // Draw direction indicator
      ctx.strokeStyle = "#c9b037"
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(gameState.player.x, gameState.player.y)
      ctx.lineTo(
        gameState.player.x + Math.cos(gameState.player.direction) * 20,
        gameState.player.y + Math.sin(gameState.player.direction) * 20,
      )
      ctx.stroke()

      animationId = requestAnimationFrame(gameLoop)
    }

    gameLoop()

    // Event listeners
    const handleKeyDown = (e: KeyboardEvent) => {
      setGameState((prev) => ({
        ...prev,
        keys: { ...prev.keys, [e.key.toLowerCase()]: true },
      }))
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      setGameState((prev) => ({
        ...prev,
        keys: { ...prev.keys, [e.key.toLowerCase()]: false },
      }))
    }

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      setGameState((prev) => ({
        ...prev,
        mouse: {
          x: e.clientX - rect.left,
          y: e.clientY - rect.top,
        },
      }))
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)
    canvas.addEventListener("mousemove", handleMouseMove)

    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener("resize", resizeCanvas)
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
      canvas.removeEventListener("mousemove", handleMouseMove)
    }
  }, [gameState.isRunning])

  // Update player position based on input
  useEffect(() => {
    const updatePlayer = () => {
      setGameState((prev) => {
        const newPlayer = { ...prev.player }

        // Movement
        if (prev.keys["w"] || prev.keys["arrowup"]) {
          newPlayer.y -= newPlayer.speed
        }
        if (prev.keys["s"] || prev.keys["arrowdown"]) {
          newPlayer.y += newPlayer.speed
        }
        if (prev.keys["a"] || prev.keys["arrowleft"]) {
          newPlayer.x -= newPlayer.speed
        }
        if (prev.keys["d"] || prev.keys["arrowright"]) {
          newPlayer.x += newPlayer.speed
        }

        // Update direction based on mouse
        const dx = prev.mouse.x - newPlayer.x
        const dy = prev.mouse.y - newPlayer.y
        newPlayer.direction = Math.atan2(dy, dx)

        // Keep player in bounds
        newPlayer.x = Math.max(10, Math.min(window.innerWidth - 10, newPlayer.x))
        newPlayer.y = Math.max(10, Math.min(window.innerHeight - 10, newPlayer.y))

        return { ...prev, player: newPlayer }
      })
    }

    const interval = setInterval(updatePlayer, 16) // ~60fps
    return () => clearInterval(interval)
  }, [gameState.keys, gameState.mouse])

  return (
    <div className="min-h-screen bg-[#1a5450] text-[#c9b037] overflow-hidden relative" dir="rtl">
      {/* Header bar with logos */}
      <div
        className="fixed top-0 left-0 right-0 flex justify-between items-center p-2 bg-[rgba(26,84,80,0.9)] border-b-2 border-[#c9b037] z-[10002] pointer-events-none"
        style={{ direction: "ltr" }}
      >
        <img src="/images/ministry-logo-updated.png" alt="شعار وزارة المالية" className="h-12 w-auto object-contain" />
        <img
          src="/images/dalili-logo-transparent-new-updated.png"
          alt="شعار دليلي"
          className="h-12 w-auto object-contain"
        />
      </div>

      {/* Game canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" style={{ background: "#1a5450" }} />

      {/* Back button */}
      <button
        onClick={() => router.push("/")}
        className="fixed bottom-8 left-8 bg-[#c9b037] text-[#1a5450] px-6 py-3 rounded-lg font-semibold hover:bg-[#ffd700] transition-colors duration-300 shadow-lg z-10"
      >
        العودة للرئيسية
      </button>

      {/* Instructions */}
      <div className="fixed bottom-8 right-8 bg-[rgba(26,84,80,0.9)] p-4 rounded-lg border border-[#c9b037] z-10">
        <h3 className="text-lg font-semibold mb-2">التحكم:</h3>
        <p className="text-sm opacity-80">استخدم WASD أو الأسهم للحركة</p>
        <p className="text-sm opacity-80">حرك الماوس لتوجيه الشخصية</p>
      </div>
    </div>
  )
}
