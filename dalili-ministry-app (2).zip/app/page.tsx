"use client"

import { GameCanvas } from "@/components/game-canvas"

export default function DaliliApp() {
  return (
    <div className="min-h-screen bg-[#1a5450] text-[#c9b037] overflow-hidden relative" dir="rtl">
      <GameCanvas />
    </div>
  )
}
