"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"

export default function TaxCalculatorPage() {
  const [selectedTaxType, setSelectedTaxType] = useState("")
  const [results, setResults] = useState<{ [key: string]: string }>({})

  // Property Sale Tax Rates
  const SALE_RATES = {
    residential: 0.01,
    commercial: 0.03,
    landInside: 0.02,
    landOutside: 0.01,
    roof: 0.01,
  }

  // Stamp Categories
  const STAMP_CATEGORIES = {
    general: { type: "percentage", rate: 0.004, label: "عقد بمبلغ محدد" },
    guarantee: { type: "percentage", rate: 0.003, label: "كفالة مالية" },
    insurance: { type: "fixed", amount: 5000, label: "وثائق تأمين" },
    partnership: { type: "mixed", baseFee: 25000, rate: 0.005, label: "شركة أشخاص" },
    jointStock: { type: "mixed", rate: 0.005, publicRate: 0.0025, label: "شركة مساهمة" },
    llc: { type: "mixed", baseFee: 25000, rate: 0.005, label: "محدودة المسؤولية" },
    documentNoAmount: { type: "fixed", amount: 5000, label: "وثيقة بلا مبلغ" },
  }

  // Tax Brackets for 2024
  const BRACKETS2024 = [
    { l: 10000000, r: 0.1 },
    { l: 30000000, r: 0.14 },
    { l: 100000000, r: 0.18 },
    { l: 500000000, r: 0.22 },
    { l: Number.POSITIVE_INFINITY, r: 0.25 },
  ]

  // Salary Tax Brackets
  const salaryBrackets_2023_09 = [
    { limit: 250000, rate: 0.05 },
    { limit: 450000, rate: 0.07 },
    { limit: 650000, rate: 0.09 },
    { limit: 850000, rate: 0.11 },
    { limit: 1100000, rate: 0.13 },
    { limit: Number.POSITIVE_INFINITY, rate: 0.15 },
  ]

  const salaryBrackets_2024_03 = [
    { limit: 450000, rate: 0.07 },
    { limit: 650000, rate: 0.09 },
    { limit: 850000, rate: 0.11 },
    { limit: 1100000, rate: 0.13 },
    { limit: Number.POSITIVE_INFINITY, rate: 0.15 },
  ]

  // Calculation Functions
  const calcInd2024 = (profit: number) => {
    let taxable = Math.max(0, profit - 3000000)
    let prev = 0
    let sum = 0

    for (const bracket of BRACKETS2024) {
      const cap = Math.min(taxable, bracket.l - prev)
      if (cap <= 0) break
      sum += cap * bracket.r
      taxable -= cap
      prev = bracket.l
    }
    return sum
  }

  const calcCorp = (profit: number, type: string) => {
    const map: { [key: string]: number } = {
      jscPublic: 0.15,
      companyOther: 0.2,
      bankInsurance: 0.25,
      oilGas: 0.35,
    }
    return profit * (map[type] || 0.2)
  }

  const calcSalaryTax = (monthly: number, brackets: any[]) => {
    let remaining = monthly
    let prev = 0
    let total = 0
    const details: any[] = []

    for (const bracket of brackets) {
      const cap = Math.min(remaining, bracket.limit - prev)
      if (cap <= 0) break
      total += cap * bracket.rate
      details.push({ amount: cap, rate: bracket.rate, tax: cap * bracket.rate })
      remaining -= cap
      prev = bracket.limit
    }
    return { total, details }
  }

  // Property Sale Calculator
  const calculatePropertyTax = (formData: FormData) => {
    const value = Number(formData.get("propValue")) || 0
    const type = formData.get("propType") as string
    const gift = formData.get("propGiftRelatives") === "on"

    let base = value * (SALE_RATES[type as keyof typeof SALE_RATES] || 0.01)
    if (gift) base *= 0.15

    const local = base * 0.1
    const reconstruction = base * 0.1
    const total = base + local + reconstruction

    return `الضريبة الأساسية: ${base.toFixed(2)} ل.س
الإدارة المحلية: ${local.toFixed(2)} ل.س
إعادة الإعمار: ${reconstruction.toFixed(2)} ل.س
الإجمالي: ${total.toFixed(2)} ل.س`
  }

  // Rent Tax Calculator
  const calculateRentTax = (formData: FormData) => {
    const rent = Number(formData.get("rentValue")) || 0
    const propertyValue = Number(formData.get("rentPropValue")) || 0
    const use = formData.get("rentUseSimple") as string
    const furnished = formData.get("rentFurnished") === "on"

    const rate = use === "residential" ? 0.05 : 0.1
    const minFactor = use === "residential" ? 0.0003 : 0.0006
    const valueForMin = use === "residential" && furnished ? propertyValue * 1.25 : propertyValue

    const tax = rent * rate
    const minimum = valueForMin * minFactor
    const due = Math.max(tax, minimum)

    return `من البدل: ${tax.toFixed(2)} ل.س
الحد الأدنى: ${minimum.toFixed(2)} ل.س
المستحق: ${due.toFixed(2)} ل.س
ملاحظة: يجب التصريح خلال 30 يوماً، والغرامة 10% عند التأخير.`
  }

  // Profit Tax Calculator
  const calculateProfitTax = (formData: FormData) => {
    const profit = Number(formData.get("profitValue")) || 0
    const taxpayerType = formData.get("profitTaxpayerType") as string
    const companyType = formData.get("profitCompanyType") as string

    let base: number
    if (taxpayerType === "individual") {
      base = calcInd2024(profit)
    } else {
      base = calcCorp(profit, companyType)
    }

    const local = base * 0.1
    const reconstruction = base * 0.1
    const total = base + local + reconstruction

    return `الأساسية: ${base.toFixed(2)} ل.س
الإدارة المحلية: ${local.toFixed(2)} ل.س
الإعمار: ${reconstruction.toFixed(2)} ل.س
الإجمالي: ${total.toFixed(2)} ل.س`
  }

  // Lump Sum Calculator
  const calculateLumpSum = (formData: FormData) => {
    const turnover = Number(formData.get("lumpTurnover")) || 0
    const margin = Number(formData.get("lumpMargin")) || 0
    const vehicles = Number(formData.get("lumpVehicles")) || 0

    const profitEst = Math.max(0, turnover * (margin / 100) - vehicles * 2000000)
    const base = calcInd2024(profitEst)
    const local = base * 0.1
    const reconstruction = base * 0.1
    const total = base + local + reconstruction

    return `الربح التقديري: ${profitEst.toFixed(2)} ل.س
الأساسية: ${base.toFixed(2)} ل.س
الإدارة المحلية: ${local.toFixed(2)} ل.س
الإعمار: ${reconstruction.toFixed(2)} ل.س
الإجمالي: ${total.toFixed(2)} ل.س
ملاحظة: هذه نتيجة تقديرية.`
  }

  // Salary Tax Calculator
  const calculateSalaryTax = (formData: FormData) => {
    const income = Number(formData.get("salaryValue")) || 0
    const period = formData.get("salaryDate") as string
    const lump = formData.get("salaryLumpOption") === "on"

    if (lump) {
      const total = income * 0.05
      return `الراتب: ${income} ل.س
الضريبة المقطوعة 5%: ${total.toFixed(2)} ل.س`
    }

    const brackets = period === "2023-09" ? salaryBrackets_2023_09 : salaryBrackets_2024_03
    const result = calcSalaryTax(income, brackets)

    let output = ""
    result.details.forEach((detail, index) => {
      output += `شريحة ${index + 1}: ${detail.amount} ل.س بنسبة ${(detail.rate * 100).toFixed(0)}% = ${detail.tax.toFixed(2)} ل.س\n`
    })
    output += `الإجمالي: ${result.total.toFixed(2)} ل.س`

    return output
  }

  // Stamp Duty Calculator
  const calculateStampDuty = (formData: FormData) => {
    const category = formData.get("stampCategory") as string
    const value = Number(formData.get("stampValue")) || 0
    const capital = Number(formData.get("stampCapital")) || 0
    const publicOffer = formData.get("stampPublicOffer") === "on"
    const copies = Number(formData.get("stampCopies")) || 1

    const cat = STAMP_CATEGORIES[category as keyof typeof STAMP_CATEGORIES]
    let base = 0

    if (cat) {
      if (cat.type === "percentage") {
        base = value * cat.rate
      } else if (cat.type === "fixed") {
        base = cat.amount
      } else if (cat.type === "mixed") {
        const rate = publicOffer && "publicRate" in cat ? cat.publicRate! : cat.rate
        base = (cat.baseFee || 0) + capital * rate
      }
    }

    const duty = base
    const national = duty * 0.1
    const local = duty * 0.05
    const perCopy = duty + national + local
    const total = perCopy * copies

    let output = `الرسوم الأساسية: ${duty.toFixed(2)} ل.س
المساهمة الوطنية 10%: ${national.toFixed(2)} ل.س
رسم الإدارة المحلية 5%: ${local.toFixed(2)} ل.س
الإجمالي للنسخة الواحدة: ${perCopy.toFixed(2)} ل.س`

    if (copies > 1) {
      output += `\nالإجمالي لجميع النسخ: ${total.toFixed(2)} ل.س`
    }

    return output
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>, calculatorType: string) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    let result = ""

    switch (calculatorType) {
      case "property":
        result = calculatePropertyTax(formData)
        break
      case "rent":
        result = calculateRentTax(formData)
        break
      case "profit":
        result = calculateProfitTax(formData)
        break
      case "lump":
        result = calculateLumpSum(formData)
        break
      case "salary":
        result = calculateSalaryTax(formData)
        break
      case "stamp":
        result = calculateStampDuty(formData)
        break
      case "profitCompare":
        result = calculateProfitComparison(formData)
        break
    }

    setResults({ ...results, [calculatorType]: result })
  }

  const calculateProfitComparison = (formData: FormData) => {
    const profit = Number(formData.get("compareProfit")) || 0

    const base24 = calcInd2024(profit)
    const base51 = profit * 0.24
    const base30 = profit * 0.3

    return `القانون 24: ${base24.toFixed(2)} ل.س
المرسوم 51: ${base51.toFixed(2)} ل.س
المرسوم 30: ${base30.toFixed(2)} ل.س`
  }

  return (
    <div className="min-h-screen relative">
      {/* Background Video */}
      <video
        className="fixed right-0 bottom-0 min-w-full min-h-full w-auto h-auto z-[-1] object-cover"
        autoPlay
        loop
        muted
        playsInline
      >
        <source src="/videos/spotlight-simplicity-storyboard.mp4" type="video/mp4" />
        متصفحك لا يدعم تشغيل الفيديو.
      </video>

      {/* Calculator Container */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen p-5">
        {/* Header */}
        <div className="flex items-center justify-between w-full max-w-4xl mb-8 p-4 bg-white bg-opacity-85 rounded-lg border border-white border-opacity-40 shadow-lg">
          <Link href="/" className="text-[#1a5450] hover:text-[#123e32] transition-colors">
            ← العودة للرئيسية
          </Link>
          <h1 className="text-2xl font-bold text-[#1a5450] text-center flex-1">حاسبة الضرائب السورية</h1>
          <div className="w-20"></div> {/* Spacer for centering */}
        </div>

        {/* Tax Type Selector */}
        <div className="w-full max-w-2xl mb-6">
          <label htmlFor="taxType" className="block mb-2 font-semibold text-sm text-[#1a5450]">
            اختر نوع الضريبة:
          </label>
          <select
            id="taxType"
            value={selectedTaxType}
            onChange={(e) => setSelectedTaxType(e.target.value)}
            className="w-full p-3 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450] appearance-none bg-[url('data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath fill='%231a5450' d='M5.516 7.548L10 12.032l4.484-4.484.816.816-5.3 5.3-5.3-5.3z'/%3E%3C/svg%3E')] bg-no-repeat bg-[right_10px_center] bg-[length:12px] pr-8"
          >
            <option value="" disabled>
              — اختر —
            </option>
            <option value="property">بيع عقار (قانون 15/2021)</option>
            <option value="rent">ضريبة الإيجار العقارية</option>
            <option value="profit">ضريبة الأرباح الحقيقية</option>
            <option value="lump">الدخل المقطوع</option>
            <option value="salary">ضريبة الرواتب والأجور</option>
            <option value="stamp">رسوم الطابع</option>
            <option value="profitCompare">مقارنة القوانين (24/51/30)</option>
          </select>
        </div>

        {/* Property Sale Section */}
        {selectedTaxType === "property" && (
          <div className="w-full max-w-2xl p-4 bg-white bg-opacity-85 rounded-md border border-white border-opacity-40 shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-[#1a5450] border-b border-black border-opacity-10 pb-2">
              بيع عقار (القانون 15 لسنة 2021)
            </h2>
            <form onSubmit={(e) => handleSubmit(e, "property")}>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                قيمة العقار (ل.س):
                <input
                  type="number"
                  name="propValue"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                نوع العقار:
                <select
                  name="propType"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450] appearance-none bg-[url('data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath fill='%231a5450' d='M5.516 7.548L10 12.032l4.484-4.484.816.816-5.3 5.3-5.3-5.3z'/%3E%3C/svg%3E')] bg-no-repeat bg-[right_10px_center] bg-[length:12px] pr-8"
                >
                  <option value="residential">سكني</option>
                  <option value="commercial">غير سكني (تجاري/صناعي)</option>
                  <option value="landInside">أرض داخل المخطط</option>
                  <option value="landOutside">أرض خارج المخطط</option>
                  <option value="roof">سطح سكني</option>
                </select>
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                <input type="checkbox" name="propGiftRelatives" className="ml-2" />
                هبة للأصول/الفروع/الزوج
              </label>
              <button
                type="submit"
                className="w-full p-3 mt-3 border-none rounded-md text-sm font-semibold text-white bg-[#1a5450] shadow-md cursor-pointer transition-colors hover:bg-[#123e32]"
              >
                احسب الضريبة
              </button>
              {results.property && (
                <div className="mt-4 p-3 bg-white bg-opacity-85 border border-white border-opacity-40 rounded whitespace-pre-wrap shadow-sm">
                  {results.property}
                </div>
              )}
            </form>
          </div>
        )}

        {/* Rent Tax Section */}
        {selectedTaxType === "rent" && (
          <div className="w-full max-w-2xl p-4 bg-white bg-opacity-85 rounded-md border border-white border-opacity-40 shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-[#1a5450] border-b border-black border-opacity-10 pb-2">
              ضريبة الإيجار العقارية
            </h2>
            <form onSubmit={(e) => handleSubmit(e, "rent")}>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                إجمالي بدل الإيجار (ل.س):
                <input
                  type="number"
                  name="rentValue"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                القيمة الرائجة (ل.س):
                <input
                  type="number"
                  name="rentPropValue"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                <input type="checkbox" name="rentFurnished" className="ml-2" />
                مفروش
              </label>
              <select
                name="rentUseSimple"
                className="w-full p-3 mt-4 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450] appearance-none bg-[url('data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath fill='%231a5450' d='M5.516 7.548L10 12.032l4.484-4.484.816.816-5.3 5.3-5.3-5.3z'/%3E%3C/svg%3E')] bg-no-repeat bg-[right_10px_center] bg-[length:12px] pr-8"
              >
                <option value="residential">سكني</option>
                <option value="commercial">تجاري/غير سكني</option>
              </select>
              <button
                type="submit"
                className="w-full p-3 mt-3 border-none rounded-md text-sm font-semibold text-white bg-[#1a5450] shadow-md cursor-pointer transition-colors hover:bg-[#123e32]"
              >
                احسب الضريبة
              </button>
              {results.rent && (
                <div className="mt-4 p-3 bg-white bg-opacity-85 border border-white border-opacity-40 rounded whitespace-pre-wrap shadow-sm">
                  {results.rent}
                </div>
              )}
            </form>
          </div>
        )}

        {/* Profit Tax Section */}
        {selectedTaxType === "profit" && (
          <div className="w-full max-w-2xl p-4 bg-white bg-opacity-85 rounded-md border border-white border-opacity-40 shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-[#1a5450] border-b border-black border-opacity-10 pb-2">
              ضريبة الأرباح الحقيقية
            </h2>
            <form onSubmit={(e) => handleSubmit(e, "profit")}>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                صافي الربح السنوي (ل.س):
                <input
                  type="number"
                  name="profitValue"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <select
                name="profitTaxpayerType"
                className="w-full p-3 mt-4 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450] appearance-none bg-[url('data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath fill='%231a5450' d='M5.516 7.548L10 12.032l4.484-4.484.816.816-5.3 5.3-5.3-5.3z'/%3E%3C/svg%3E')] bg-no-repeat bg-[right_10px_center] bg-[length:12px] pr-8"
              >
                <option value="individual">فرد/شركات أشخاص</option>
                <option value="corporate">شركة أموال</option>
              </select>
              <select
                name="profitCompanyType"
                className="w-full p-3 mt-4 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450] appearance-none bg-[url('data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath fill='%231a5450' d='M5.516 7.548L10 12.032l4.484-4.484.816.816-5.3 5.3-5.3-5.3z'/%3E%3C/svg%3E')] bg-no-repeat bg-[right_10px_center] bg-[length:12px] pr-8"
              >
                <option value="jscPublic">شركة مساهمة عامة (&gt;40% اكتتاب)</option>
                <option value="companyOther">باقي الشركات</option>
                <option value="bankInsurance">مصارف/تأمين</option>
                <option value="oilGas">نفط وغاز</option>
              </select>
              <button
                type="submit"
                className="w-full p-3 mt-3 border-none rounded-md text-sm font-semibold text-white bg-[#1a5450] shadow-md cursor-pointer transition-colors hover:bg-[#123e32]"
              >
                احسب الضريبة
              </button>
              {results.profit && (
                <div className="mt-4 p-3 bg-white bg-opacity-85 border border-white border-opacity-40 rounded whitespace-pre-wrap shadow-sm">
                  {results.profit}
                </div>
              )}
            </form>
          </div>
        )}

        {/* Lump Sum Section */}
        {selectedTaxType === "lump" && (
          <div className="w-full max-w-2xl p-4 bg-white bg-opacity-85 rounded-md border border-white border-opacity-40 shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-[#1a5450] border-b border-black border-opacity-10 pb-2">
              الدخل المقطوع (تقديري)
            </h2>
            <form onSubmit={(e) => handleSubmit(e, "lump")}>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                رقم العمل السنوي (ل.س):
                <input
                  type="number"
                  name="lumpTurnover"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                هامش ربح تقديري %:
                <input
                  type="number"
                  name="lumpMargin"
                  defaultValue="15"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                عدد السيارات (إن وجِد):
                <input
                  type="number"
                  name="lumpVehicles"
                  defaultValue="0"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <button
                type="submit"
                className="w-full p-3 mt-3 border-none rounded-md text-sm font-semibold text-white bg-[#1a5450] shadow-md cursor-pointer transition-colors hover:bg-[#123e32]"
              >
                احسب الضريبة
              </button>
              {results.lump && (
                <div className="mt-4 p-3 bg-white bg-opacity-85 border border-white border-opacity-40 rounded whitespace-pre-wrap shadow-sm">
                  {results.lump}
                </div>
              )}
            </form>
          </div>
        )}

        {/* Salary Tax Section */}
        {selectedTaxType === "salary" && (
          <div className="w-full max-w-2xl p-4 bg-white bg-opacity-85 rounded-md border border-white border-opacity-40 shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-[#1a5450] border-b border-black border-opacity-10 pb-2">
              ضريبة الرواتب والأجور
            </h2>
            <form onSubmit={(e) => handleSubmit(e, "salary")}>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                الراتب الشهري الإجمالي (ل.س):
                <input
                  type="number"
                  name="salaryValue"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                تاريخ الاستحقاق:
                <select
                  name="salaryDate"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450] appearance-none bg-[url('data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath fill='%231a5450' d='M5.516 7.548L10 12.032l4.484-4.484.816.816-5.3 5.3-5.3-5.3z'/%3E%3C/svg%3E')] bg-no-repeat bg-[right_10px_center] bg-[length:12px] pr-8"
                >
                  <option value="2023-09">من 1/9/2023 حتى 29/2/2024</option>
                  <option value="2024-03">من 1/3/2024 وما بعد</option>
                </select>
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                <input type="checkbox" name="salaryLumpOption" className="ml-2" />
                الضريبة المقطوعة (5%)
              </label>
              <button
                type="submit"
                className="w-full p-3 mt-3 border-none rounded-md text-sm font-semibold text-white bg-[#1a5450] shadow-md cursor-pointer transition-colors hover:bg-[#123e32]"
              >
                احسب الضريبة
              </button>
              {results.salary && (
                <div className="mt-4 p-3 bg-white bg-opacity-85 border border-white border-opacity-40 rounded whitespace-pre-wrap shadow-sm">
                  {results.salary}
                </div>
              )}
            </form>
          </div>
        )}

        {/* Stamp Duty Section */}
        {selectedTaxType === "stamp" && (
          <div className="w-full max-w-2xl p-4 bg-white bg-opacity-85 rounded-md border border-white border-opacity-40 shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-[#1a5450] border-b border-black border-opacity-10 pb-2">
              رسوم الطابع
            </h2>
            <form onSubmit={(e) => handleSubmit(e, "stamp")}>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                الفئة:
                <select
                  name="stampCategory"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450] appearance-none bg-[url('data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath fill='%231a5450' d='M5.516 7.548L10 12.032l4.484-4.484.816.816-5.3 5.3-5.3-5.3z'/%3E%3C/svg%3E')] bg-no-repeat bg-[right_10px_center] bg-[length:12px] pr-8"
                >
                  {Object.entries(STAMP_CATEGORIES).map(([key, cat]) => (
                    <option key={key} value={key}>
                      {cat.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                قيمة الأساس (ل.س):
                <input
                  type="number"
                  name="stampValue"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                رأس المال (ل.س):
                <input
                  type="number"
                  name="stampCapital"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                <input type="checkbox" name="stampPublicOffer" className="ml-2" />
                طرح أسهم للاكتتاب العام
              </label>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                عدد النسخ:
                <input
                  type="number"
                  name="stampCopies"
                  defaultValue="2"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <button
                type="submit"
                className="w-full p-3 mt-3 border-none rounded-md text-sm font-semibold text-white bg-[#1a5450] shadow-md cursor-pointer transition-colors hover:bg-[#123e32]"
              >
                احسب الرسوم
              </button>
              {results.stamp && (
                <div className="mt-4 p-3 bg-white bg-opacity-85 border border-white border-opacity-40 rounded whitespace-pre-wrap shadow-sm">
                  {results.stamp}
                </div>
              )}
            </form>
          </div>
        )}

        {/* Profit Comparison Section */}
        {selectedTaxType === "profitCompare" && (
          <div className="w-full max-w-4xl p-4 bg-white bg-opacity-85 rounded-md border border-white border-opacity-40 shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-[#1a5450] border-b border-black border-opacity-10 pb-2">
              مقارنة ضريبة الأرباح (قانون 24 / مرسوم 51 / مرسوم 30)
            </h2>
            <form onSubmit={(e) => handleSubmit(e, "profitCompare")}>
              <label className="block mt-4 font-semibold text-sm text-[#1a5450]">
                الربح السنوي (ل.س):
                <input
                  type="number"
                  name="compareProfit"
                  className="w-full p-3 mt-2 border border-gray-400 rounded-md text-sm bg-white bg-opacity-95 text-[#1a5450]"
                />
              </label>
              <button
                type="submit"
                className="w-full p-3 mt-3 border-none rounded-md text-sm font-semibold text-white bg-[#1a5450] shadow-md cursor-pointer transition-colors hover:bg-[#123e32]"
              >
                احسب المقارنة
              </button>
              {results.profitCompare && (
                <div className="mt-4 p-3 bg-white bg-opacity-85 border border-white border-opacity-40 rounded whitespace-pre-wrap shadow-sm">
                  {results.profitCompare}
                </div>
              )}
            </form>
          </div>
        )}
      </div>
    </div>
  )
}
