"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Search, FileText, Clock, CheckCircle, XCircle } from "lucide-react"

export default function FollowUpPage() {
  const router = useRouter()
  const [referenceNumber, setReferenceNumber] = useState("")
  const [searchResult, setSearchResult] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleSearch = async () => {
    if (!referenceNumber.trim()) return

    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      // Mock data for demonstration
      const mockResult = {
        referenceNumber: referenceNumber,
        type: referenceNumber.startsWith("C") ? "شكوى" : "اقتراح",
        status: Math.random() > 0.5 ? "قيد المراجعة" : "مكتملة",
        submissionDate: "2024-01-15",
        lastUpdate: "2024-01-20",
        department: "إدارة الضرائب",
        description: "شكوى متعلقة بالخدمات الضريبية الإلكترونية",
        response: Math.random() > 0.5 ? "تم حل المشكلة وإرسال الرد عبر البريد الإلكتروني" : null,
      }
      setSearchResult(mockResult)
      setIsLoading(false)
    }, 1500)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "مكتملة":
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case "قيد المراجعة":
        return <Clock className="w-5 h-5 text-yellow-500" />
      case "مرفوضة":
        return <XCircle className="w-5 h-5 text-red-500" />
      default:
        return <FileText className="w-5 h-5 text-blue-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "مكتملة":
        return "bg-green-100 text-green-800"
      case "قيد المراجعة":
        return "bg-yellow-100 text-yellow-800"
      case "مرفوضة":
        return "bg-red-100 text-red-800"
      default:
        return "bg-blue-100 text-blue-800"
    }
  }

  return (
    <div className="min-h-screen bg-[#1a5450] text-[#c9b037] relative" dir="rtl">
      {/* Islamic Pattern Background */}
      <div
        className="absolute inset-0 pointer-events-none z-[1] opacity-[0.08]"
        style={{
          backgroundImage: "url('/images/pattern-white-converted.png')",
          backgroundRepeat: "repeat",
          backgroundSize: "400px auto",
          backgroundPosition: "center",
        }}
      />

      {/* Header */}
      <div className="relative z-10 bg-[#1a5450]/90 backdrop-blur-sm border-b border-[#c9b037]/20">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => router.push("/")} className="text-[#c9b037] hover:bg-[#c9b037]/10">
              <ArrowRight className="w-5 h-5 ml-2" />
              العودة للرئيسية
            </Button>
            <img src="/images/dalili-logo-transparent-new.png" alt="دليلي" className="h-12" />
          </div>
          <img src="/images/ministry-logo.png" alt="وزارة المالية" className="h-12 opacity-80" />
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">متابعة الشكاوى والاقتراحات</h1>
            <p className="text-lg opacity-80">أدخل رقم المرجع لمتابعة حالة شكواك أو اقتراحك</p>
          </div>

          {/* Search Form */}
          <Card className="bg-[#2a6b66]/50 border-[#c9b037]/30 backdrop-blur-sm mb-6">
            <CardHeader>
              <CardTitle className="text-[#c9b037] flex items-center gap-2">
                <Search className="w-5 h-5" />
                البحث برقم المرجع
              </CardTitle>
              <CardDescription className="text-[#c9b037]/70">
                أدخل رقم المرجع الذي تم إرساله إليك عند تقديم الشكوى أو الاقتراح
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="مثال: C2024001 أو S2024001"
                  value={referenceNumber}
                  onChange={(e) => setReferenceNumber(e.target.value)}
                  className="bg-[#1a5450]/50 border-[#c9b037]/30 text-[#c9b037] placeholder:text-[#c9b037]/50"
                  onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                />
                <Button
                  onClick={handleSearch}
                  disabled={!referenceNumber.trim() || isLoading}
                  className="bg-[#c9b037] text-[#1a5450] hover:bg-[#ffd700] px-6"
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-[#1a5450] border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Search className="w-5 h-5" />
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Search Results */}
          {searchResult && (
            <Card className="bg-[#2a6b66]/50 border-[#c9b037]/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-[#c9b037] flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    تفاصيل {searchResult.type}
                  </span>
                  <Badge className={`${getStatusColor(searchResult.status)} flex items-center gap-1`}>
                    {getStatusIcon(searchResult.status)}
                    {searchResult.status}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-[#c9b037]/80">رقم المرجع</label>
                    <p className="text-[#c9b037] font-mono">{searchResult.referenceNumber}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-[#c9b037]/80">نوع الطلب</label>
                    <p className="text-[#c9b037]">{searchResult.type}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-[#c9b037]/80">تاريخ التقديم</label>
                    <p className="text-[#c9b037]">{searchResult.submissionDate}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-[#c9b037]/80">آخر تحديث</label>
                    <p className="text-[#c9b037]">{searchResult.lastUpdate}</p>
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-sm font-medium text-[#c9b037]/80">الإدارة المختصة</label>
                    <p className="text-[#c9b037]">{searchResult.department}</p>
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-sm font-medium text-[#c9b037]/80">الوصف</label>
                    <p className="text-[#c9b037]">{searchResult.description}</p>
                  </div>
                  {searchResult.response && (
                    <div className="md:col-span-2">
                      <label className="text-sm font-medium text-[#c9b037]/80">الرد</label>
                      <div className="bg-[#1a5450]/50 p-3 rounded-lg border border-[#c9b037]/20 mt-1">
                        <p className="text-[#c9b037]">{searchResult.response}</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Help Section */}
          <Card className="bg-[#2a6b66]/30 border-[#c9b037]/20 backdrop-blur-sm mt-6">
            <CardContent className="pt-6">
              <h3 className="text-lg font-semibold text-[#c9b037] mb-3">هل تحتاج مساعدة؟</h3>
              <div className="space-y-2 text-[#c9b037]/80">
                <p>• رقم المرجع يبدأ بـ C للشكاوى و S للاقتراحات</p>
                <p>• يمكنك العثور على رقم المرجع في رسالة التأكيد المرسلة إليك</p>
                <p>• في حالة عدم وجود رقم المرجع، يرجى التواصل مع خدمة العملاء</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
