"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"

export default function SuggestionCategoryPage() {
  const router = useRouter()
  const [selectedCategory, setSelectedCategory] = useState("")

  const suggestionCategories = [
    { id: "service-improvement", label: "تحسين الخدمات", description: "اقتراحات لتطوير الخدمات الحالية" },
    { id: "new-service", label: "خدمة جديدة", description: "اقتراح خدمات جديدة" },
    { id: "system-enhancement", label: "تطوير الأنظمة", description: "اقتراحات لتحسين الأنظمة التقنية" },
    { id: "policy-suggestion", label: "اقتراح سياسة", description: "اقتراحات حول السياسات والإجراءات" },
    { id: "other", label: "أخرى", description: "اقتراحات أخرى" },
  ]

  const handleNext = () => {
    if (selectedCategory) {
      localStorage.setItem("suggestion_category", selectedCategory)
      router.push("/submit/suggestion/details")
    }
  }

  return (
    <div className="min-h-screen bg-[#1a5450] text-[#c9b037] overflow-hidden relative" dir="rtl">
      {/* Home Button */}
      <div className="absolute top-4 left-4 z-10">
        <Link
          href="/"
          className="bg-transparent border-2 border-[#c9b037] text-[#c9b037] px-4 py-2 rounded-lg font-semibold hover:bg-[#c9b037] hover:text-[#1a5450] transition-colors duration-300"
        >
          العودة للرئيسية
        </Link>
      </div>

      {/* Ministry Logo */}
      <div className="absolute top-4 right-4 z-10">
        <img src="/images/ministry-logo.png" alt="وزارة المالية" className="h-16 opacity-80" />
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-2xl text-[#1a5450] p-8">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8 border-b border-gray-200 pb-6">
            <div className="text-4xl">🏛️</div>
            <div>
              <div className="text-xl font-bold text-[#c9b037]">وزارة المالية</div>
              <div className="text-sm text-gray-600">نظام دليلي الضريبي - تقديم اقتراح</div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="flex justify-between items-center mb-8 border-b border-gray-200 pb-6">
            {["الفئة", "التفاصيل", "المرفقات", "المراجعة", "الإرسال"].map((step, i) => (
              <div key={i} className="flex flex-col items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold ${
                    i === 0 ? "bg-[#1a5450] text-white" : "bg-gray-200 text-gray-500"
                  }`}
                >
                  {i + 1}
                </div>
                <div className={`text-xs mt-2 ${i === 0 ? "text-[#1a5450]" : "text-gray-500"}`}>{step}</div>
              </div>
            ))}
          </div>

          {/* Content */}
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold mb-2">اختيار فئة الاقتراح</h2>
              <p className="text-gray-600">يرجى اختيار الفئة المناسبة لضمان معالجة طلبكم من الجهة المختصة</p>
            </div>

            <div className="space-y-3">
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                فئة الطلب: <span className="text-red-500">*</span>
              </label>
              {suggestionCategories.map((category) => (
                <div
                  key={category.id}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                    selectedCategory === category.id
                      ? "border-[#1a5450] bg-[#1a5450] bg-opacity-5"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <div className="flex items-start gap-3">
                    <input
                      type="radio"
                      name="category"
                      value={category.id}
                      checked={selectedCategory === category.id}
                      onChange={() => setSelectedCategory(category.id)}
                      className="mt-1"
                    />
                    <div>
                      <div className="font-semibold text-gray-800">{category.label}</div>
                      <div className="text-sm text-gray-600 mt-1">{category.description}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Guidance */}
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
              <div className="font-semibold text-gray-800 mb-2">كيف يُعالج اقتراحك؟</div>
              <div className="text-sm text-gray-600 space-y-1">
                <div>• سيتم توجيه اقتراحك إلى القسم المختص</div>
                <div>• ستحصل على رقم متابعة خلال 24 ساعة</div>
                <div>• مدة المعالجة: 5-10 أيام عمل</div>
                <div>• سيتم إشعارك بالنتيجة عبر الهاتف أو البريد الإلكتروني</div>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleNext}
                disabled={!selectedCategory}
                className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
                  selectedCategory
                    ? "bg-[#1a5450] text-white hover:bg-[#0f3835]"
                    : "bg-gray-300 text-gray-500 cursor-not-allowed"
                }`}
              >
                التالي ←
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
